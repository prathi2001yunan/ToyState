package tech.crypton.practice.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.crypton.practice.R
import tech.crypton.practice.modals.ProductToy
import tech.crypton.practice.ui.viewmodel.ToyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToyScreen(viewModel: ToyViewModel, onTap: (id: String) -> Unit) {
    val mode by viewModel.isModGrid.collectAsState()
    val alert by viewModel.alert.collectAsState()
    val keyword by viewModel.keyword.collectAsState()
    val filteredToys by viewModel.filteredToys.collectAsState()
    val cartSet by viewModel.cartSet.collectAsState()
    Scaffold(
        topBar = {
            TopAppBar({ it -> viewModel.onDisplayAlert(it) }, cartSize = cartSet.size)
        },
        bottomBar = {
            BottomAppBar()
        }
    ) { paddingValues ->
        // rest of the app's UI
        Column(
            modifier =
            Modifier
                .fillMaxSize()
                .padding(paddingValues = paddingValues)
                .padding(top = 20.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (alert) {
                val formattedPrice = String.format("%.2f", viewModel.getTotal())
                AlertDialog(
                    title = {
                        Text(text = "Cart Items")
                    },
                    text = {
                        Text(
                            text = if (cartSet.isEmpty()) "No Items in cart" else "Total items in cart ${cartSet.size} and Total price is $formattedPrice",
                            fontSize = 18.sp
                        )
                    },
                    onDismissRequest = {
                        viewModel.onDisplayAlert(false)
                    },
                    confirmButton = {
                        TextButton(
                            onClick = { viewModel.onDisplayAlert(false) }
                        ) {
                            Text(text = "Okay")
                        }
                    }
                )
            }
            TopSearchView(
                keyword = keyword,
                mode,
                { str -> viewModel.search(str) },
                { boolean -> viewModel.changeMode(!boolean) })
            Row(
                modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(top = 25.dp),
                Arrangement.Start,
                Alignment.CenterVertically
            ) {
                Text(
                    text = "Best selling toys",
                    fontWeight = FontWeight.Bold,
                    fontSize = 25.sp
                )
            }
            Spacer(modifier = Modifier.size(20.dp))
            if (filteredToys.isEmpty()) {
                Text(
                    text = "No Items found",
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
            } else {
                if (mode) {
                    ToyListView(onTap, filteredToys,
                        { it -> viewModel.isInFavorite(it) },
                        cartSet,
                        { toyId -> viewModel.addToCart(toyId) },
                        { toyId -> viewModel.removeFromCart(toyId) }
                    )
                } else {
                    ToyGridView(
                        onTap,
                        filteredToys,
                        { it -> viewModel.isInFavorite(it) },
                        cartSet,
                        { toyId -> viewModel.addToCart(toyId) },
                        { toyId -> viewModel.removeFromCart(toyId) },
                    )
                }
            }
        }
    }
}


@Composable
fun ToyGridView(
    onTap: (id: String) -> Unit,
    toys: List<ProductToy>,
    isFavorite: (id: String) -> Boolean,
    cartSet: Set<String>,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit,
) {
    LazyVerticalGrid(
        modifier = Modifier.padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(space = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(space = 20.dp),
        columns = GridCells.Fixed(2),
        userScrollEnabled = true,
    ) {
        items(toys.size) { it ->
            val product = toys.elementAt(it)
            ToyGridItemView(
                onTap = onTap,
                toy = product,
                isFavorite = isFavorite(product.id),
                isInCart = product.id in cartSet,
                onAddCart = onAddCart,
                onRemoveCart = onRemoveCart
            )

        }
    }
}

@Composable
fun ToyListView(
    onTap: (toyId: String) -> Unit,
    toys: List<ProductToy>,
    isFavorite: (id: String) -> Boolean,
    cartSet: Set<String>,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.padding(horizontal = 20.dp),
    ) {
        items(toys.size) {
            val product = toys.elementAt(it)
            ToyListItemView(
                toy = product,
                isFavorite = isFavorite(product.id),
                isInCart = product.id in cartSet,
                onAddCart = onAddCart,
                onRemoveCart = onRemoveCart,
                onTap = onTap
            )
            Spacer(modifier = Modifier.size(10.dp))
        }
    }
}


@Composable
fun ToyListItemView(
    toy: ProductToy,
    isFavorite: Boolean,
    isInCart: Boolean,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit,
    onTap: (toyId: String) -> Unit
) {
    Box(modifier = Modifier
        .fillMaxWidth()
        .height(80.dp)
        .clip(RoundedCornerShape(15.dp))
        .clickable {
            onTap(toy.id)
        }
        .background(toy.color, RoundedCornerShape(15.dp))) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp)
        ) {
            Row(
                modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                Arrangement.SpaceBetween,
                Alignment.CenterVertically
            ) {
                Text(text = toy.title, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = "",
                    modifier = Modifier.size(20.dp),
                    tint = if (isFavorite) Color.Black else Color(0xFFFE594D)
                )
            }
            Spacer(modifier = Modifier.size(5.dp))
            Row(
                modifier =
                Modifier
                    .fillMaxWidth(),
                Arrangement.Start,
                Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "",
                    modifier = Modifier.size(12.dp),
                    tint = Color(0xFFDDBA50)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = "${toy.noStars} Star", fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.size(5.dp))
            Text(text = "$${toy.price}", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }
        Box(
            modifier = Modifier
                .height(32.dp)
                .align(Alignment.BottomEnd)
                .clip(RoundedCornerShape(0.dp, 0.dp, 0.dp, 0.dp))
                .background(
                    Color(0xFF5F52F9),
                    RoundedCornerShape(0.dp, 0.dp, 0.dp, 0.dp),
                )
                .clickable {
                    if (!isInCart) {
                        onAddCart(toy.id)
                    } else {
                        onRemoveCart(toy.id)
                    }
                }
        ) {
            Text(
                text = if (!isInCart) "Add to cart" else "Remove from cart",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 10.dp),
                color = Color.White
            )
        }
    }
}

@Composable
private fun TopAppBar(onChangeAlertMode: (alert: Boolean) -> Unit, cartSize: Int) {
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(top = 20.dp)
            .padding(start = 20.dp),
        horizontalArrangement = Arrangement.End
    ) {
        Box(modifier = Modifier.size(75.dp)) {
            if (cartSize > 0) {
                Row(
                    modifier = Modifier
                        .size(30.dp)
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F0FF), CircleShape),
                    Arrangement.Center,
                    Alignment.CenterVertically
                ) {
                    Text(text = cartSize.toString(), fontSize = 20.sp)
                }
            }
            Column(modifier = Modifier.align(Alignment.Center)) {
                BoxIconComponent(
                    icon = R.drawable.baseline_shopping_cart_24,
                    backGroundColor = Color(0xFF5F52F9),
                    iconColor = Color.White,
                    25.dp
                ) { onChangeAlertMode(true) }
            }
        }
    }
}

@Composable
private fun BottomAppBar() {
    var selectedItem by rememberSaveable { mutableIntStateOf(0) }

    val items =
        listOf<ImageVector>(
            Icons.Filled.Home,
            Icons.Default.Lock,
            Icons.Default.ShoppingCart,
            Icons.Filled.Favorite,
            Icons.Filled.Person
        )
    BottomAppBar(
        content = {
            NavigationBar(containerColor = Color(0xFF5F52F9)) {
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = items[index],
                                contentDescription = "",
                                tint = if (selectedItem == index) Color.White else Color.LightGray
                            )
                        },
                        selected = selectedItem == index,
                        onClick = {
                            selectedItem = index
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFF5F52F9)
                        )
                    )
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopSearchView(
    keyword: String,
    isModeGrid: Boolean,
    onSearch: (keyword: String) -> Unit,
    onChangeMode: (isModeGrid: Boolean) -> Unit
) {
    TextField(
        value = keyword,
        onValueChange = { onSearch(it) },
        textStyle = MaterialTheme.typography.titleSmall.copy(fontSize = 14.sp),
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clip(RoundedCornerShape(12.dp))
            .height(65.dp),
        colors = TextFieldDefaults.textFieldColors(
            containerColor = Color(0xFFF1F0FF),
            focusedIndicatorColor = Color(0xFFF1F0FF),
            unfocusedIndicatorColor = Color(0xFFF1F0FF)
        ),

        placeholder = {
            Text(
                text = "Search your toys",
                fontSize = 14.sp,
                fontWeight = FontWeight.W600
            )
        },
        singleLine = true,
        trailingIcon = {
            Row {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_window_24),
                    contentDescription = "",
                    tint = Color.Black,
                    modifier =
                    Modifier
                        .size(45.dp)
                        .padding(start = 20.dp)
                        .clickable {
                            onChangeMode(isModeGrid)
                        }
                )
                Spacer(modifier = Modifier.width(20.dp))
            }
        },
        leadingIcon = {
            Row {
                Spacer(modifier = Modifier.width(20.dp))
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "",
                    tint = Color.Black,
                    modifier = Modifier.size(30.dp)
                )
            }
        },
    )
}

@Composable
fun BoxIconComponent(
    icon: Int,
    backGroundColor: Color,
    iconColor: Color,
    iconSize: Dp,
    onClick: () -> Unit
) {
    Box(
        modifier =
        Modifier
            .size(35.dp)
            .background(backGroundColor, RoundedCornerShape(5.dp, 5.dp, 5.dp, 5.dp))
            .clickable { onClick() }
            .clip(RoundedCornerShape(5.dp, 5.dp, 5.dp, 5.dp))
    ) {
        Icon(
            painter = painterResource(id = icon),
            contentDescription = "",
            modifier =
            Modifier
                .size(iconSize)
                .align(Alignment.Center),
            tint = iconColor
        )
    }
}

@Composable
private fun ToyGridItemView(
    onTap: (toyId: String) -> Unit,
    toy: ProductToy,
    isFavorite: Boolean,
    isInCart: Boolean,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit,
) {
    Box(
        modifier =
        Modifier
            .height(210.dp)
            .clip(RoundedCornerShape(15.dp))
            .clickable {
                onTap(toy.id)
            }
            .background(toy.color)
    ) {
        Column(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
        ) {
            Row(
                modifier =
                Modifier
                    .fillMaxWidth(),
                Arrangement.SpaceBetween,
                Alignment.CenterVertically
            ) {
                Text(text = toy.title, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = "",
                    modifier = Modifier.size(20.dp),
                    tint = if (isFavorite) Color.Black else Color(0xFFFE594D)
                )
            }
            Spacer(modifier = Modifier.size(2.dp))
            Row(
                modifier =
                Modifier
                    .fillMaxWidth(),
                Arrangement.Start,
                Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "",
                    modifier = Modifier.size(12.dp),
                    tint = Color(0xFFDDBA50)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(text = "${toy.noStars} Star", fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.size(5.dp))
            Text(text = "$${toy.price}", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            Row(modifier = Modifier.fillMaxWidth(), Arrangement.Center, Alignment.Top) {
                Image(
                    painter = painterResource(id = toy.image),
                    contentDescription = "",
                    modifier =
                    Modifier.size(80.dp)
                )
            }
        }
        Box(
            modifier = Modifier
                .height(32.dp)
                .align(Alignment.BottomEnd)
                .clip(RoundedCornerShape(0.dp, 0.dp, 0.dp, 0.dp))
                .background(
                    Color(0xFF5F52F9),
                    RoundedCornerShape(0.dp, 0.dp, 0.dp, 0.dp),
                )
                .clickable {
                    if (!isInCart) {
                        onAddCart(toy.id)
                    } else {
                        onRemoveCart(toy.id)
                    }
                }
        ) {
            Text(
                text = if (!isInCart) "Add to cart" else "Remove from cart",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 10.dp),
                color = Color.White
            )
        }
    }
}









