package tech.crypton.practice.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import tech.crypton.practice.modals.CartToyItem
import tech.crypton.practice.modals.ProductToy


class ToyViewModel(
    private val filteredToysData: List<ProductToy>
) : ViewModel() {
    private var _alert = MutableStateFlow<Boolean>(false)
    val alert = _alert.asStateFlow()
    private var _dropDownMenu = MutableStateFlow<Boolean>(false)
    val dropDownMenu = _dropDownMenu.asStateFlow()
    private var _filteredToys = MutableStateFlow<List<ProductToy>>(listOf())
    val filteredToys = _filteredToys.asStateFlow()
    private var _isModGrid = MutableStateFlow<Boolean>(false)
    var isModGrid = _isModGrid.asStateFlow()
    private var _keyword = MutableStateFlow<String>("")
    var keyword = _keyword.asStateFlow()
    private var _favoriteSet = MutableStateFlow<Set<String>>(setOf())
    var favoriteSet = _favoriteSet.asStateFlow()
    private var _cartSet = MutableStateFlow<Set<String>>(setOf())
    var cartSet = _cartSet.asStateFlow()
    private var _cartData = MutableStateFlow<CartToyItem>(CartToyItem())
    var cartData = _cartData.asStateFlow()
    private val toys = filteredToysData
    private var cartItems = mutableListOf<CartToyItem>()

    init {
        _filteredToys.value = toys
    }

    private var total: Double = 0.0

    fun onDisplayAlert(alert: Boolean) {
        _alert.value = alert
    }

    fun onShowDrop(show: Boolean) {
        _dropDownMenu.value = !show
    }

    fun search(keyword: String) {
        _keyword.value = keyword
        if (keyword.isEmpty()) {
            _filteredToys.value = toys
        } else {
            _filteredToys.value = toys.filter { it.title.contains(keyword, ignoreCase = true) }
        }
    }

    fun getTotal(): Double {
        return total
    }

    fun changeMode(isModeGrid: Boolean) {
        _isModGrid.value = isModeGrid
    }

    fun getToy(toyId: String): ProductToy? {
        return toys.find { it.id == toyId }
    }

    fun getCartData(toyId: String) {
        val toy = getToy(toyId)
        if (toy!!.id in cartSet.value) {
            _cartData.value = cartItems.filter { it.toyId == toyId }[0]
        } else {
            _cartData.value = CartToyItem(toyId, 1, toy.price)
        }
    }

    fun addFavorite(toyId: String) {
        _favoriteSet.value += toyId
    }

    fun removeFavorite(toyId: String) {
        _favoriteSet.value -= toyId
    }

    fun getToyQuantity(toyId: String): Int {
        val item = cartItems.find { it.toyId == toyId }
        return item?.quantity ?: 1
    }

    fun isInFavorite(toyId: String): Boolean {
        return _favoriteSet.value.contains(toyId)
    }

    fun removeQuantity(toyId: String, quantity: Int) {
        if (quantity > 1) {
            val cartItem = cartItems.filter { it.toyId == toyId }[0]
            val toy = getToy(toyId)
            cartItem.quantity = quantity - 1
            cartItem.total -= toy!!.price
            val amount = toy.price
            if (cartItem.toyId in _cartSet.value) {
                val index = _cartSet.value.indexOf(cartItem.toyId)
                cartItems[index] = cartItem
            }
            _cartData.value = CartToyItem(toyId, quantity - 1, amount * (quantity - 1))
            total = cartItems.sumOf { it.total }
        }
    }

    fun addToCart(toyId: String, quantity: Int = 1) {
        val cartItem = CartToyItem(toyId, quantity, 0.0)
        val toy = getToy(toyId)
        cartItem.total = toy!!.price * cartItem.quantity
        if (cartItem.toyId in _cartSet.value) {
            val index = _cartSet.value.indexOf(cartItem.toyId)
            cartItems[index] = cartItem
        } else {
            cartItems.add(cartItem)
            _cartSet.value += cartItem.toyId
        }
        Log.d("data", cartItems.toString())
        total = cartItems.sumOf { it.total }
        _cartData.value = cartItem
    }

    fun removeFromCart(toyId: String) {
        val item = cartItems.filter { it.toyId == toyId }[0]
        cartItems -= item
        _cartSet.value -= item.toyId
        val toy = getToy(toyId)
        _cartData.value = CartToyItem(toyId, 1, toy!!.price)
        total = cartItems.sumOf { it.total }
    }
}

