package tech.crypton.practice.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import tech.crypton.practice.R
import tech.crypton.practice.ToyData
import tech.crypton.practice.ui.viewmodel.ToyViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToyDetailScreen(
    viewModel: ToyViewModel,
    data: ToyData,
    onBack: () -> Unit
) {
    val toy = viewModel.getToy(data.id)
    viewModel.getCartData(toy?.id ?: "")
    val favouriteSet by viewModel.favoriteSet.collectAsState()
    val cartSet by viewModel.cartSet.collectAsState()
    val data1 by viewModel.cartData.collectAsState()
    val dropMenu by viewModel.dropDownMenu.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(toy?.color ?: Color.White)
            ) {
                ToyDetailTopAppBar(
                    dropMenu,
                    { it: Boolean -> viewModel.onShowDrop(it) },
                    onBack,
                    toy?.title ?: "",
                    toy?.color ?: Color.White,
                    (toy?.id ?: "") in favouriteSet,
                    { viewModel.addFavorite(toy?.id ?: "") },
                    { viewModel.removeFavorite(toy?.id ?: "") })
            }
        },
        bottomBar = {
            ToyDetailBottomAppBar(
                toy?.id ?: "",
                data1.total,
                toy?.id in cartSet,
                { id -> viewModel.addToCart(id) },
                { id -> viewModel.removeFromCart(id) })
        },
    ) { paddingValues ->
        Column(
            modifier =
            Modifier
                .fillMaxSize()
                .padding(paddingValues = paddingValues)
                .background(toy?.color ?: Color.White),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = data.image),
                contentDescription = "",
                modifier = Modifier.fillMaxSize(0.6f)
            )
            Box(
                modifier =
                Modifier
                    .fillMaxWidth()
                    .height(500.dp)
                    .background(Color.White, RoundedCornerShape(40.dp, 40.dp, 0.dp, 0.dp))
                    .clip(RoundedCornerShape(40.dp, 40.dp, 0.dp, 0.dp))
            ) {
                Column(
                    modifier =
                    Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        Arrangement.SpaceBetween,
                        Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Best tidy bear & style",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.width(180.dp)
                        )
                        QuantityItem(data1.toyId, data1.quantity, { id ->
                            viewModel.addToCart(
                                id,
                                data1.quantity + 1
                            )
                        }) { id ->
                            viewModel.removeQuantity(
                                toyId = id,
                                data1.quantity
                            )
                        }
                    }
                    Spacer(modifier = Modifier.size(30.dp))
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        item {
                            Text(
                                toy!!.description,
                                fontSize = 12.sp,
                                lineHeight = 20.sp,
                                color = Color(0xFF77757C),
                                fontWeight = FontWeight.W600
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun ToyDetailBottomAppBar(
    toyId: String,
    price: Double,
    cartSet: Boolean,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit
) {
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .height(80.dp)
            .padding(horizontal = 20.dp),
        Arrangement.SpaceBetween,
        Alignment.Top
    ) {

        val formattedPrice = String.format("%.2f", price)
        Column {
            Text(
                text = "$$formattedPrice",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Total payable",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF979699)
            )
        }
        ToyDetailAddCartButton(toyId = toyId, cartSet, onAddCart, onRemoveCart)
    }
}

@OptIn(ExperimentalMaterial3Api::class, DelicateCoroutinesApi::class)
@Composable
private fun ToyDetailTopAppBar(
    showMenu: Boolean,
    onChangeDrop: (it: Boolean) -> Unit,
    onBack: () -> Unit,
    name: String,
    color: Color,
    isFavourite: Boolean,
    onAddFavourite: () -> Unit,
    onRemoveFavourite: () -> Unit
) {

    CenterAlignedTopAppBar(
        title = {
            Text(
                text = name,
                color = Color.White,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }, navigationIcon =
        {
            BoxIconComponent(
                icon = R.drawable.baseline_arrow_back_ios_24,
                backGroundColor = Color.White,
                iconColor = Color.Black,
                15.dp,
                onBack
            )
        }, colors = TopAppBarDefaults.largeTopAppBarColors(color),
        actions = {
            Box(
                modifier =
                Modifier
                    .size(35.dp)
                    .background(Color.White, RoundedCornerShape(5.dp, 5.dp, 5.dp, 5.dp))
                    .clickable { onChangeDrop(showMenu) }
                    .clip(RoundedCornerShape(5.dp, 5.dp, 5.dp, 5.dp))
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_more_vert_24),
                    contentDescription = "",
                    modifier =
                    Modifier
                        .size(25.dp)
                        .align(Alignment.Center),
                    tint = Color.Black
                )
            }
            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { onChangeDrop(showMenu) },
            ) {
                DropdownMenuItem(
                    text = { Text(text = if (isFavourite) "Remove Favourite" else "Add Favourite") },
                    onClick = {
                        onChangeDrop(showMenu)
                        GlobalScope.launch {
                            delay(1000L)
                            if (isFavourite) {
                                onRemoveFavourite()
                            } else {
                                onAddFavourite()
                            }
                        }
                    }
                )
            }
        }, modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(top = 20.dp)
    )

}


@Composable
private fun ToyDetailAddCartButton(
    toyId: String,
    cartSet: Boolean,
    onAddCart: (toyId: String) -> Unit,
    onRemoveCart: (toyId: String) -> Unit
) {
    Box(
        modifier =
        Modifier
            .width(175.dp)
            .height(55.dp)
            .clickable {
                if (cartSet) {
                    onRemoveCart(toyId)
                } else {
                    onAddCart(toyId)
                }
            }
            .background(Color(0xFF5F52F9), RoundedCornerShape(30.dp)),
    ) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 5.dp)
                .align(alignment = Alignment.Center),
            Arrangement.Start,
            Alignment.CenterVertically
        ) {
            Box(
                modifier =
                Modifier
                    .size(50.dp)
                    .background(Color(0xFF7E73FF), CircleShape)
                    .clip(CircleShape)
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_shopping_cart_24),
                    contentDescription = "",
                    modifier =
                    Modifier
                        .size(25.dp)
                        .align(Alignment.Center),
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.size(20.dp))
            Text(
                text = if (!cartSet) "Add to cart" else "Remove from cart",
                fontSize = 11.sp,
                color = Color(0xFFE2E2E4),
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
private fun QuantityItem(
    id: String,
    quantity: Int,
    onAddCart: (toyId: String) -> Unit,
    onRemoveQuantity: (toyId: String) -> Unit
) {
    Box(
        modifier =
        Modifier
            .width(140.dp)
            .height(50.dp)
            .background(Color(0xFFCAC5FC), RoundedCornerShape(25.dp, 25.dp, 25.dp, 25.dp))
            .clip(RoundedCornerShape(25.dp, 25.dp, 25.dp, 25.dp))
    ) {
        Row(
            modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 15.dp),
            Arrangement.SpaceBetween,
            Alignment.CenterVertically
        ) {
            Text(
                text = "+",
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable {
                    onAddCart(id)
                })
            Text(text = quantity.toString(), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "-",
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable {
                    onRemoveQuantity(id)
                })
        }
    }
}
