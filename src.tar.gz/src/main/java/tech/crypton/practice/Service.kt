package tech.crypton.practice

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder

class Service1: Service() {
    private lateinit var player: MediaPlayer
    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }
}