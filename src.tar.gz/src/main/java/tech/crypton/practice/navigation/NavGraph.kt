package tech.crypton.practice.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import tech.crypton.practice.ToyDataBase
import tech.crypton.practice.ui.screens.ToyDetailScreen
import tech.crypton.practice.ui.screens.ToyScreen
import tech.crypton.practice.ui.viewmodel.ToyViewModel

@Composable
fun NavGraph(viewModel: ToyViewModel ,navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = NavRoute.ToyScreen.route,
    ) {
        composable(route = NavRoute.ToyScreen.route) {
            ToyScreen(viewModel) { str -> navController.navigate("${NavRoute.ToyDetailScreen.route}/$str") }
        }
        composable(
            route = "${NavRoute.ToyDetailScreen.route}/{key}",
            arguments = listOf(navArgument("key") { type = NavType.StringType }),
        ) {
            it.arguments?.getString("key")?.let { data ->
                ToyDetailScreen(viewModel,data = ToyDataBase.getData(data)) {
                    navController.popBackStack()
                }
            }
        }
    }
}
