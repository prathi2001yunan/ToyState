package tech.crypton.practice.navigation

sealed class NavRoute(val route: String) {
    object ToyScreen : NavRoute("toy_screen")

    object ToyDetailScreen : NavRoute("toy_detail_screen")
}
