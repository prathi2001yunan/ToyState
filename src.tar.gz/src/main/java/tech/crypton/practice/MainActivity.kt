package tech.crypton.practice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import tech.crypton.practice.modals.ProductToy
import tech.crypton.practice.navigation.NavGraph
import tech.crypton.practice.ui.theme.PraticeTheme
import tech.crypton.practice.ui.viewmodel.ToyViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PraticeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    val toyList = listOf<ProductToy>(
                        ProductToy(
                            "1",
                            "Capkoty toy",
                            "5",
                            23.56,
                            Color(0xFFD2CEFF),
                            R.drawable.avatar1,
                            "Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Moments Begin! Snuggle Up to Tidy Bear Where Cozy Moments Begin! Snuggle Up nov bear where cozy Moments seoin re be naooy to nelo vou create a toy descriotion. could you orovide more delais aout the type of toy you have in mind? For example, is it a plush tov Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy\","
                        ),
                        ProductToy(
                            "2",
                            "Teddy toy",
                            "4",
                            27.56,
                            Color(0xFFCCECF0),
                            R.drawable.avatar2,
                            "Pallanguzhi is a traditional two-player strategy board game that has been played in South India for centuris The game board consists of two rows of seven samll pitswhich a player pit or storehouse at each end.   The objective if the game is to capture as many seeds or countersas possible from your opponent's pits and store them in your own storehouse.  The Wooden Pallanguzhi Game is a beautiful and traditional,  board game that has been played in South India."
                        ),
                        ProductToy(
                            "3",
                            "Cap toy",
                            "5",
                            34.56,
                            Color(0xFFE7D9FF),
                            R.drawable.avatar3,
                            "Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Moments Begin! Snuggle Up to Tidy Bear Where Cozy Moments Begin! Snuggle Up nov bear where cozy Moments seoin re be naooy to nelo vou create a toy descriotion. could you orovide more delais aout the type of toy you have in mind? For example, is it a plush tov Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy\","
                        ),
                        ProductToy(
                            "4",
                            "Bear toy",
                            "2",
                            53.56,
                            Color(0xFFD9F8FF),
                            R.drawable.avatar4,
                            "Pallanguzhi is a traditional two-player strategy board game that has been played in South India for centuris The game board consists of two rows of seven samll pitswhich a player pit or storehouse at each end.   The objective if the game is to capture as many seeds or countersas possible from your opponent's pits and store them in your own storehouse.  The Wooden Pallanguzhi Game is a beautiful and traditional,  board game that has been played in South India."
                        ),
                        ProductToy(
                            "5",
                            "Koty toy",
                            "5",
                            21.56,
                            Color(0xFFFFD9E0),
                            R.drawable.avatar5,
                            "race the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Moments Begin! Snuggle Up to Tidy Bear Where Cozy Moments Begin! Snuggle Up nov bear where cozy Moments seoin re be naooy to nelo vou create a toy descriotion. could you orovide more delais aout the type of toy you have in mind? For example, is it a plush tov Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy\\\",\"),"
                        ),
                        ProductToy(
                            "6",
                            "Ranger toy",
                            "2",
                            43.56,
                            Color(0xFFFFF0D9),
                            R.drawable.avatar1,
                            "Pallanguzhi is a traditional two-player strategy board game that has been played in South India for centuris The game board consists of two rows of seven samll pitswhich a player pit or storehouse at each end.   The objective if the game is to capture as many seeds or countersas possible from your opponent's pits and store them in your own storehouse.  The Wooden Pallanguzhi Game is a beautiful and traditional,  board game that has been played in South India."
                        ),
                        ProductToy(
                            "7",
                            "Watch toy",
                            "4",
                            11.56,
                            Color(0xFFD2CEFF),
                            R.drawable.avatar2,
                            "race the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Moments Begin! Snuggle Up to Tidy Bear Where Cozy Moments Begin! Snuggle Up nov bear where cozy Moments seoin re be naooy to nelo vou create a toy descriotion. could you orovide more delais aout the type of toy you have in mind? For example, is it a plush tov Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy\\\",\"),"
                        ),
                        ProductToy(
                            "8",
                            "Mango toy",
                            "3",
                            25.56,
                            Color(0xFFCCECF0),
                            R.drawable.avatar3,
                            "Pallanguzhi is a traditional two-player strategy board game that has been played in South India for centuris The game board consists of two rows of seven samll pitswhich a player pit or storehouse at each end.   The objective if the game is to capture as many seeds or countersas possible from your opponent's pits and store them in your own storehouse.  The Wooden Pallanguzhi Game is a beautiful and traditional,  board game that has been played in South India."
                        ),
                        ProductToy(
                            "9",
                            "Banana toy",
                            "5",
                            12.56,
                            Color(0xFFE7D9FF),
                            R.drawable.avatar4,
                            "race the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Moments Begin! Snuggle Up to Tidy Bear Where Cozy Moments Begin! Snuggle Up nov bear where cozy Moments seoin re be naooy to nelo vou create a toy descriotion. could you orovide more delais aout the type of toy you have in mind? For example, is it a plush tov Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy Embrace the Hug Life with Tidy Bear - Where Cuddles and Comfort Collide Snuggle Up to Tidy Bear: Where Cozy\\\",\"),"
                        )
                    )
                    NavGraph(viewModel = ToyViewModel(toyList))
                }
            }
        }
    }
}

