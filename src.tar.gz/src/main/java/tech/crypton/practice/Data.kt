package tech.crypton.practice

import androidx.compose.ui.graphics.Color

data class ToyData(
    val id: String,
    val name: String,
    val image: Int,
    val price: Int,
    val reviewStar: Int,
    val color: Color
)

object ToyDataBase {
    val toyData =
        listOf<ToyData>(
            ToyData("1", "Capkoty toy", R.drawable.avatar1, 23, 5, Color(0xFFCCECF0)),
            ToyData("2", "Panda toy", R.drawable.avatar2, 13, 5, Color(0xFFEC8A83)),
            ToyData("3", "Teddy toy", R.drawable.avatar3, 83, 5, Color(0xFF6FB2E7)),
            ToyData("4", "Powdy toy", R.drawable.avatar4, 24, 5, Color(0xFF63EBDE)),
            ToyData("5", "Cap toy", R.drawable.avatar5, 73, 5, Color(0xFFB6725C)),
            ToyData("6", "Mango toy", R.drawable.avatar1, 13, 5, Color(0xFFC87FD5)),
            ToyData("7", "Apple toy", R.drawable.avatar3, 65, 5, Color(0xFFA3D6A5)),
            ToyData("8", "Carrot toy", R.drawable.avatar4, 33, 5, Color(0xFF515053)),
            ToyData("9", "Ben toy", R.drawable.avatar5, 40, 5, Color(0xFF59C2B8))
        )

    fun getData(id: String): ToyData {
        return toyData.filter { it.id == id }[0]
    }
}
