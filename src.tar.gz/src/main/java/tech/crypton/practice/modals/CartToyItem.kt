package tech.crypton.practice.modals

data class CartToyItem(val toyId: String = "", var quantity: Int = 0, var total: Double = 0.0)

