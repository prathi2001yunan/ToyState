package tech.crypton.practice.modals

import androidx.compose.ui.graphics.Color

data class ProductToy(
    val id: String = "",
    val title: String = "",
    val noStars: String = "",
    val price: Double = 0.0,
    val color: Color = Color.White,
    val image: Int,
    val description: String = ""
)
